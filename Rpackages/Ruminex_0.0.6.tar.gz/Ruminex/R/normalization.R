dat.check=function(dat){
    
    # make sure sample_id x replicate_number x dilution uniquely identifies a well
    if (!"replicate_number" %in% colnames(dat)) {
        warning("replicate_number missing")
    } else {
        if (anyDuplicated(subset(dat, well_role=="Unknown", select=c(analyte, assay_id, sample_id, dilution, replicate_number)))!=0) stop("duplicated analyte, sample_id, dilution, assay_id, replicate_number combination")
    }        
    if (anyDuplicated(subset(dat, well_role=="Unknown", select=c(analyte, assay_id, plateid, well)))!=0) stop("duplicated analyte, assay_id, plateid, well combination")
    
    # remove columns varying in sample_id x replicate_number
    varying=c()
    for (cl in colnames(dat)) {
        if(cl!="fi" & cl!="well" & cl!="plateid") {
            uniqueness = aggregate(dat[,cl], by=dat[,c("analyte", "assay_id", "sample_id", "dilution")], FUN=function(x) 1==length(unique(x)))
            all.same = all(uniqueness[,ncol(uniqueness)])
            if (!all.same) varying=c(varying, cl)
        }
    }
    if(!is.null(varying)) dat=dat[,-match(varying, colnames(dat))]
        
    dat
    
}


# adjust blank well, can be used for both unk and standard
remove.background=function (dat) {
    
    ana=sort(unique(dat$analyte))
    assays=sort(unique(dat$assay_id))
    dat.out=data.frame()
    for (p in assays) {            
        for (a in ana) {            
        
            dat.a.p=subset(dat, assay_id==p & analyte==a)
            if (nrow(dat.a.p)==0) next 
            
            # there may be multiple panels in a dataset
            dects = unique(dat.a.p$detection_reagent)
            for (dect in dects){
            
                dat.bkg=subset(dat.a.p, well_role=="Background" & detection_reagent==dect)
                if (nrow(dat.bkg)==0) {
                    warning("no background wells found for "%+%a%+%" and "%+%dect)
                    bkg=0
                }  else {
                    bkg=mean(dat.bkg$fi)
                }
                
                dat.a.p.unk=subset(dat.a.p, well_role!="Background" & detection_reagent==dect )
                if (nrow(dat.a.p.unk)==0) {
                    next
                } else {
                    dat.a.p.unk$fi = dat.a.p.unk$fi - bkg
                    dat.out=rbind(dat.out, dat.a.p.unk)
                }        
                
            } # end dects loop
        } # end ana loop
    } # end assays loop
    
    dat.out
}
# remove.background(dat)

# adjusting for blank beads
adjust.blank.bead=function(dat.unk) {
    
    idvar = c("assay_id", "plateid", "well")
    v.name="fi"
    
    ana=sort(unique(dat.unk$analyte))
    ana=setdiff(ana, "blank")
    
    tmp.wide  = reshape (dat.unk, direction='wide',idvar=idvar,timevar='analyte', v.names=v.name)
    
    dat.out = reshape (tmp.wide, direction='long',
                       varying = lapply(v.name,function(x) x%+%"."%+%ana), 
                       v.names=v.name%+%".ana", 
                       idvar=idvar, timevar="analyte", times=ana)
    dat.out[,v.name]=dat.out[,v.name%+%".ana"] - dat.out[,v.name%+%"."%+%"blank"]
    #dat.out$y=dat.out$y.ana-dat.out$y.blank
    dat.out=dat.out[,-which(names(dat.out) %in% (v.name%+%".ana"))]
    dat.out=dat.out[,-which(names(dat.out) %in% (v.name%+%"."%+%"blank"))]
    
    # there may be missing data now, due to the two reshaping
    #if(nrow(subset(dat.out, is.na(fi)))!=0) warning("some fi missing after adjusting for blank bead")
    dat.out=subset(dat.out, !is.na(fi)) # this is most likely ok
    
    dat.out
}

ave.replicates=function(dat.unk){
    
    dat.fi = aggregate(dat.unk[,"fi"], by=dat.unk[,c("analyte", "sample_id", "dilution")], FUN=mean)    
    
    varying=c()
    for (cl in colnames(dat.unk)) {
        uniqueness = aggregate(dat.unk[,cl], by=dat.unk[,c("analyte", "sample_id", "dilution")], FUN=function(x) 1==length(unique(x)))
        all.same = all(uniqueness[,ncol(uniqueness)])
        if (!all.same) varying=c(varying, cl)
    }
    if(!is.null(varying)) dat.unk=dat.unk[,-match(varying, colnames(dat.unk))]
    dat.unk=unique(dat.unk)
        
    dat = merge(dat.unk,dat.fi,by=c("sample_id","analyte","dilution"))
    colnames(dat)[colnames(dat)=="x"]="fi"
    dat
}


# combine standard and unknown samples
combine.rumi=function(dat.std, dat.unk, ...){
    
    cols=c("assay_id","well_role","dilution","fi","analyte","starting_conc")
    if("ptid" %in% names(dat.unk)) cols=c(cols,"ptid")
    if("visit" %in% names(dat.unk)) cols=c(cols,"visit")
    
    # there are two cases: 1) each analyte has a standard, 2) all share a standard    
    ana.unk=sort(unique(dat.unk$analyte))
    ana.std=sort(unique(dat.std$analyte))
    if(all(ana.unk==ana.std)) {
        has.separate.std=TRUE
    } else if (length(ana.std)==1){
        has.separate.std=FALSE
    } else {
        stop("standard samples not right")
    }
    
    dat=data.frame()
    for (a in ana.unk) {
        if(!has.separate.std) tmp=dat.std[,cols] else tmp=dat.std[dat.std$analyte==a,cols] 
        tmp$analyte=a
        dat=rbind(dat, tmp)            
    }
    dat=rbind(cbind(dat,sample_id=NA),dat.unk[,c(cols,"sample_id")])
    
    ce = rumi(dat, plot=FALSE, force.fit=TRUE, ...)
    ce$ce=exp(ce$est.log.conc)
    ce=subset(ce, select=-c(se,est.log.conc,starting_conc))    
    
}


normi=function(dat, adj.blank.unk=TRUE, return.ce=FALSE, ...){
    
    dat = dat.check(dat)
        
    dat = remove.background (dat)
    
    #separate out unknown and standard b/c we don't adjust.blank.bead for standard
    dat.unk = subset(dat, well_role=="Unknown")
    if (adj.blank.unk) dat.unk = adjust.blank.bead (dat.unk)    
    
    dat.std = subset(dat, well_role=="Standard" & analyte!="blank")
    
    if(!return.ce) {
        dat.unk = ave.replicates(dat.unk)
        #if (any(dat.unk$fi<0)) dat.unk$fi=pmax(dat.unk$fi,0)+1
        dat.unk
    } else {
        #if (any(dat.unk$fi<0)) dat.unk$fi=pmax(dat.unk$fi,0)+1
        #if (any(dat.std$fi<0)) dat.std$fi=pmax(dat.std$fi,0)+1
        combine.rumi(dat.std, dat.unk, ...)    
    }
    
}

#dat=read.csv("../adata/USM_LUM_GT_ADCC_raw_data_20100924.csv")
#dat$assay_id=dat$plateid
#dat=subset(dat, well_role!="Control")
#dat.out=(dat, adj.blank.unk=TRUE, return.ce=FALSE)
