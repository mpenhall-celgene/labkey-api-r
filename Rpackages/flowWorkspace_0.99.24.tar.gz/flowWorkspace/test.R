# TODO: Add comment
# 
# Author: mike
###############################################################################

#unloadNamespace("ncdfFlow")
#unloadNamespace("flowWorkspace")
library(ncdfFlow)
library(flowWorkspace)

#library(ncdf4)
setwd("~")
#d<-system.file("extdata/",package="flowWorkspaceData")
#ws<-openWorkspace(file=paste(d,"A2004Analysis.xml",sep="/"))
d<-"/home/mike/rglab/data/MAC_tube"
ws<-openWorkspace(file=paste(d,"MAC91_tube15.xml",sep="/"))
time1=Sys.time()
G<-parseWorkspace(ws,execute=TRUE,isNcdf=TRUE,path=d,name=1,subset=(c(1)))

#saveNcdf("G","ddd1")

getData(G[[1]],2)
	
Sys.time()-time1






